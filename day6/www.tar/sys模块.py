#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/10/19 21:54
# @Author  : Evescn
# @Site    : 
# @File    : sys.py
# @Software: PyCharm
import sys
print(sys.stdout.write("please:"))   # 进度条使用
print(sys.platform)
print(sys.path)
print(sys.version)
print(sys.argv)
